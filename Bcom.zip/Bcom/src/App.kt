/**
 * Luís Henrique Beltrão Santana
 *
 */
val label = mutableMapOf<String,Int>()

fun main(args: Array<String>){
    val asm = "\t\t\tMOVLW 1           ; 1 -> w\n" +
            "\t\t\tMOVWF FSR         ; w -> fsr\n" +
            "\t\t\tCLRF INDF         ; 0 -> indf[fsr]\n" +
            "\tram:\tINCF FSR,1       ; fsr++\n" +
            "\t\t\tMOVF FSR,0       ; fsr -> w\n" +
            "\t\t\tMOVWF INDF        ; w -> indf[fsr]\n" +
            "\t\t\tSUBLW 32          ; 32 - w -> w\n" +
            "\t\t\tBTFSS STATUS,2    ; pula a proxima instrução se a ultima operação resultou em 0\n" +
            "\t\t\tGOTO ram\n" +
            "\t\t\tMOVLW 2           ; 2 -> w\n" +
            "\t\t\tMOVWF FSR         ; w -> fsr\n" +
            "\tcrivo2: CLRF INDF         ; 0 -> indf[fsr]\n" +
            "\t\t\tINCF FSR,1        ; fsr++\n" +
            "\t\t\tINCF FSR,1        ; fsr++\n" +
            "\t\t\tMOVLW 32          ; 32 -> w\n" +
            "\t\t\tSUBWF FSR,0       ; fsr - w -> w\n" +
            "\t\t\tMOVWF \$1          ; w -> \$1\n" +
            "\t\t\tBTFSC \$1,7        ; pula a proxima instrução se fsr > w\n" +
            "\t\t\tGOTO crivo2\n" +
            "\t\t\tMOVLW 3           ; 3 -> w\n" +
            "\t\t\tMOVWF FSR         ; w -> fsr\n" +
            "\tcrivo3: CLRF INDF         ; 0 -> indf[fsr]\n" +
            "\t\t\tINCF FSR,1        ; fsr++\n" +
            "\t\t\tINCF FSR,1        ; fsr++\n" +
            "\t\t\tINCF FSR,1        ; fsr++\n" +
            "\t\t\tMOVLW 32          ; 32 -> w\n" +
            "\t\t\tSUBWF FSR,0       ; fsr - w -> w\n" +
            "\t\t\tMOVWF \$1          ; w -> \$1\n" +
            "\t\t\tBTFSC \$1,7        ; pula a proxima instrução se fsr > w\n" +
            "\t\t\tGOTO crivo3\n" +
            "\t\t\tMOVLW 5           ; 5 -> w\n" +
            "\t\t\tMOVWF FSR         ; w -> fsr\n" +
            "\tcrivo5: CLRF INDF         ; 0 -> indf[fsr]\n" +
            "\t\t\tMOVLW 5           ; 5 -> w\n" +
            "\t\t\tADDWF FSR,1       ; w + fsr -> fsr\n" +
            "\t\t\tMOVLW 32          ; 32 -> w\n" +
            "\t\t\tSUBWF FSR,0       ; fsr - w -> w\n" +
            "\t\t\tMOVWF \$1          ; w -> \$1\n" +
            "\t\t\tBTFSC \$1,7        ; pula a proxima instrução se fsr > w\n" +
            "\t\t\tGOTO crivo5\n" +
            "\tloop:\tMOVLW 0           ; 0 -> w\n" +
            "\t\t\tMOVWF FSR         ; w -> fsr\n" +
            "\tloop2:  INCF FSR,1        ; fsr++\n" +
            "\t\t\tMOVLW 0           ; 0 -> w\n" +
            "\t\t\tSUBWF INDF,0\t  ; indf - 0 -> w\n" +
            "\t\t\tBTFSS STATUS,2    ; pula a proxima instrução se a ultima operação resultou em 0\n" +
            "\t\t\tGOTO show\n" +
            "\t\t\tMOVLW 32          ; 32 -> w\n" +
            "\t\t\tSUBWF FSR,0       ; fsr - w -> w\n" +
            "\t\t\tMOVWF \$1          ; w -> \$1\n" +
            "\t\t\tBTFSC \$1,7        ; pula a proxima instrução se fsr > w\n" +
            "\t\t\tGOTO loop2\n" +
            "\t\t\tGOTO loop\n" +
            "\tshow:\tMOVF INDF,0       ; indif -> w\n" +
            "\t\t\tMOVWF PORTB\t\t  ; w -> portb\n" +
            "\t\t\tGOTO loop2"

    val l = asm.split("\n")
    val temp = mutableListOf<String>()
    //remove tab
    l.forEach {
        val s = it.replace("\t","")
        temp.add(s)
    }
    val lines = mutableListOf<String>()
    lines.addAll(temp)
    temp.clear()
    // remover comentários
    lines.forEach{
        val s = it.split(";")[0].trim()
        temp.add(s)
    }
    lines.clear()
    lines.addAll(temp)
    temp.clear()
    // processando labels e formatando
    var i = 0
    lines.forEach{
        val s = it.split(":")
        when(s.size ) {
            1 -> temp.add(s[0].trim().replace(" ",",").toUpperCase())
            2 -> {
                label[s[0].toUpperCase()] = i
                temp.add(s[1].trim().replace(" ",",").toUpperCase())
            }
            else -> {}
        }
        i++
    }
    lines.clear()
    lines.addAll(temp)
    temp.clear()
    lines.forEach {
        temp.add(pic8AoC13(it))
    }
    lines.clear()
    lines.addAll(temp)
    lines.forEach { println(it) }
}

fun pic8AoC13(s: String): String{
    val value = mutableListOf<String>()
    value.addAll(s.split(","))
    var i = 0
    //seta os endereços
    value.forEach {
        val bd = BinaryData(6)
        value[i] = when(it){
            "$0" -> bd.set(0).binaryString()
            "FSR" -> bd.set(1).binaryString()
            "TRISA" -> bd.set(2).binaryString()
            "TRISB" -> bd.set(3).binaryString()
            "PORTA" -> bd.set(4).binaryString()
            "PORTB" -> bd.set(5).binaryString()
            "$1" -> bd.set(6).binaryString()
            "$2" -> bd.set(7).binaryString()
            "$3" -> bd.set(8).binaryString()
            "$4" -> bd.set(9).binaryString()
            "$5" -> bd.set(10).binaryString()
            "$6" -> bd.set(11).binaryString()
            "$7" -> bd.set(12).binaryString()
            "$8" -> bd.set(13).binaryString()
            "$9" -> bd.set(14).binaryString()
            "$10" -> bd.set(15).binaryString()
            "$11" -> bd.set(16).binaryString()
            "$12" -> bd.set(17).binaryString()
            "$13" -> bd.set(18).binaryString()
            "$14" -> bd.set(19).binaryString()
            "$15" -> bd.set(20).binaryString()
            "STATUS" -> bd.set(61).binaryString()
            "INDF" -> bd.set(62).binaryString()
            else -> it
        }
        i++
    }
    return when(value[0]){
        "ADDLW" -> {
            val k = BinaryData(8)
            return "11111${k.set(value[1].toInt())}"
        }
        "ADDWF" -> "000111${value[2]}${value[1]}"
        "BTFSS" -> {
            val b = BinaryData(3).set(value[2].toInt()).binaryString()
            return "0111$b${value[1]}"
        }
        "BTFSC" -> {
            val b = BinaryData(3).set(value[2].toInt()).binaryString()
            return "0110$b${value[1]}"
        }
        "CLRF" -> "0000011${value[1]}"
        "GOTO" -> {
            val v = value[1]
            val lab = label[v]
            lab?.let {
                val k = BinaryData(10).set(it).binaryString()
                return "101$k"
            }
            return s
        }
        "INCF" -> "001010${value[2]}${value[1]}"
        "MOVF" -> "001000${value[2]}${value[1]}"
        "MOVLW" -> {
            val k = BinaryData(8).set(value[1].toInt()).binaryString()
            return "11000$k"
        }
        "MOVWF" -> "0000001${value[1]}"
        "SUBLW" -> {
            val k = BinaryData(8).set(value[1].toInt()).binaryString()
            return "11110$k"
        }
        "SUBWF" -> "000010${value[2]}${value[1]}"
        else -> s
    }
}