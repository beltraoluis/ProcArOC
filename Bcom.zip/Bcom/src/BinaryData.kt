import java.lang.Math.pow
import java.util.ArrayList
import java.util.Stack

class BinaryData {

    private var data: ArrayList<Bit>? = null
    private var mbyte: Int = 0

    constructor() {
        data = ArrayList()
        this.mbyte = 8
    }

    constructor(div: Int) {
        data = ArrayList()
        this.mbyte = div
    }

    fun set(b: Bit): BinaryData{
        data!!.add(b)
        return this
    }

    fun set(v: Int): BinaryData {
        val stack = Stack<Int>()
        var i = v
        while (i != 0 && i != 1) {
            stack.push(i % 2)
            i = i / 2
        }
        try {
            stack.push(i)
            if (mbyte > 0) {
                while (stack.size % mbyte != 0) {
                    stack.push(0)
                }
            }
            while (!stack.empty()) {
                data!!.add(Bit(stack.pop()))
            }
        } catch (ignored: NullPointerException) {
        }
        return this
    }

    fun set(s: String): BinaryData {
        data!!.clear()
        mbyte = 8
        for (i in 0 until s.length) {
            set(s[i].toInt())
        }
        return this
    }

    fun print() {
        for (b in data!!) {
            print(b.get())
        }
        print("b")
    }

    fun println() {
        for (b in data!!) {
            print(b.get())
        }
        print("b\n")
    }

    fun byteSize(): String {
        val sb = StringBuilder("")
        if (mbyte % 8 == 0) {
            var tam = data!!.size.toFloat() / 8
            if (tam >= 1073741824) {
                tam = tam / 1073741824
                sb.append(tam)
                sb.append(" GiB")
            } else {
                if (tam >= 1048576) {
                    tam = tam / 1048576
                    sb.append(tam)
                    sb.append(" MiB")
                } else {
                    if (tam >= 1024) {
                        tam = tam / 1024
                        sb.append(tam)
                        sb.append(" MiB")
                    } else {
                        sb.append(tam)
                        sb.append(" Bytes")

                    }
                }
            }
        }
        return sb.toString()
    }

    fun size(): Int {
        return data!!.size
    }

    override fun toString(): String {
        val sb = StringBuilder("")
        var `val`: Int
        if (mbyte % 8 == 0) {
            val tam = data!!.size / 8
            for (i in 0 until tam) {
                `val` = 0
                for (j in 0..7) {
                    `val` += (data!![8 * i + j].get() * pow(2.0, (7 - j).toDouble())).toInt()
                }
                sb.append(`val`.toChar())
            }
        }
        return sb.toString()
    }

    fun binaryString(): String {
        val sb = StringBuilder()
        for (b in data!!) {
            if (b.isEstado) {
                sb.append('1')
            } else {
                sb.append('0')
            }
        }
        return sb.toString()
    }

    operator fun get(i: Int): Int {
        return data!![i].get()
    }
}