class Bit @Throws(NullPointerException::class)
constructor(i: Int) {

    var isEstado: Boolean = false

    init {
        isEstado = when (i) {
            0 -> false
            1 -> true
            else -> throw NullPointerException("valor invalido")
        }
    }

    fun get(): Int {
        return if (isEstado) {
            1
        } else 0
    }

    @Throws(NullPointerException::class)
    fun set(i: Int) {
        isEstado = when (i) {
            0 -> false
            1 -> true
            else -> throw NullPointerException("valor invalido")
        }
    }

}